import React,{useState} from "react";
import userContext from "./UserContext";


const UserContextProvider = ({ children }) => {
    const [data, setData] = useState([]);
    const [ArchiveData, setArchive]=useState([]);
    const [UnArchive, setUnArchive]= useState([]);
    return (
        <userContext.Provider value={{ data, setData, ArchiveData, setArchive, UnArchive, setUnArchive }}>
            {children}
            
        </userContext.Provider>
    );
};

export default UserContextProvider;
